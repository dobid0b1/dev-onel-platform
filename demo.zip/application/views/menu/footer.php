<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-left">
                <ul class="nav">
                    <li class="nav-item">
                        <!-- <a href="javascript:void(0);" class="nav-link"> -->

                        <!-- <span class='text-secondary'>YES I AM</span> -->
                        <!-- </a> -->
                    </li>
                    <!-- <li class="nav-item">
                        <a href="javascript:void(0);" class="nav-link">
                            Footer Link 2
                        </a>
                    </li> -->
                </ul>
            </div>
            <div class="app-footer-right">
                <ul class="nav">
                    <!-- <li class="nav-item">
                        <a href="javascript:void(0);" class="nav-link">
                            Footer Link 3
                        </a>
                    </li> -->
                    <li class="nav-item">
                        <span class='text-secondary'>©2021, Create by Onelth.com</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>